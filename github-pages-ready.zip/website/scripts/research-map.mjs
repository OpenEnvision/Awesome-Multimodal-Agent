import {esc} from '../../assets/site/library.js';

const contributions = [
  ['systems', 'Agent systems', 'Complete runtimes with multimodal observations, grounded actions, and feedback.'],
  ['models', 'Models & components', 'Reusable policies, perception, memory, and other learned capabilities.'],
  ['methods', 'Learning & planning', 'Algorithms for learning, tool use, world models, and coordination.'],
  ['benchmarks', 'Benchmarks & data', 'Tasks, datasets, environments, and protocols that measure agent behavior.']
];
const domains = [
  ['Information & media', 'Search, inspect, and gather evidence'],
  ['Creative workflows', 'Generate, edit, and verify artifacts'],
  ['Conversation & interaction', 'Listen, respond, and coordinate'],
  ['Software & interfaces', 'Operate browsers, desktops, and apps'],
  ['Virtual & 3D worlds', 'Navigate and act in simulated spaces'],
  ['Robotics & physical worlds', 'Sense, manipulate, and coordinate robots']
];

export function researchMap(catalog, template) {
  const collection = id => {
    const c = catalog.collections.find(c => c.id === id);
    if (!c) throw new Error(`Missing research collection: ${id}`);
    return c;
  };
  const contributionRows = contributions.map(([id, title, description]) => {
    const c = collection(id);
    return `<a class="contribution-row" href="?collection=${id}#library" data-collection="${id}"><span class="map-index">${String(c.number).padStart(2,'0')}</span><div><h4>${esc(title)}</h4><p>${esc(description)}</p></div><span class="map-count">${c.count}<span aria-hidden="true"> ↗</span></span></a>`;
  }).join('');
  const domainRows = domains.map(([title, example], index) => {
    const links = [['systems',3,'Systems'],['benchmarks',6,'Benchmarks']].map(([id,chapter,label])=> {
      const section = catalog.sections.find(s=>s.id===`${id}/${chapter}-${index+1}`);
      if (!section) throw new Error(`Missing action domain: ${id}/${index+1}`);
      return `<a href="?collection=${id}&amp;section=${section.id}#library" data-section="${section.id}" aria-label="${esc(title)}: ${label.toLowerCase()} (${section.count})">${label} <span>${section.count}</span><span aria-hidden="true"> ↗</span></a>`;
    }).join('');
    return `<li class="domain-row"><div><h4>${esc(title)}</h4><p>${esc(example)}</p></div><div class="domain-links">${links}</div></li>`;
  }).join('');
  const resources = ['surveys','engineering','skills','related'].map(id=> {
    const c = collection(id);
    return `<a href="?collection=${id}#library" data-collection="${id}">${esc(c.label)} <span>${c.count}</span> ↗</a>`;
  }).join('');
  return template.replace('{{CONTRIBUTIONS}}',contributionRows).replace('{{DOMAINS}}',domainRows).replace('{{MAP_RESOURCES}}',resources);
}
