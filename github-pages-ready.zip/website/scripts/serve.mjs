import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
const prefix='/Awesome-Multimodal-Agent';
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.txt':'text/plain; charset=utf-8','.xml':'application/xml'};
const server=http.createServer(async(req,res)=>{
 try{
  let name=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  if(name===prefix){res.writeHead(302,{Location:prefix+'/'});return res.end();}
  if(name.startsWith(prefix+'/'))name=name.slice(prefix.length);
  if(name.endsWith('/'))name+='index.html';
  const file=path.resolve(root,'.'+name);
  if(!file.startsWith(root+path.sep)){res.writeHead(403);return res.end('Forbidden');}
  const relative=path.relative(root,file).split(path.sep).join('/');
  if(!['index.html','robots.txt','sitemap.xml','README.md','.nojekyll'].includes(relative)&&!relative.startsWith('assets/')){res.writeHead(404);return res.end('Not found');}
  const bytes=await fs.readFile(file);
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]??'application/octet-stream','Cache-Control':'no-cache'});
  res.end(req.method==='HEAD'?undefined:bytes);
 }catch{res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');}
});
server.listen(5173,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:5173/ (also supports /Awesome-Multimodal-Agent/)'));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>process.exit(0)));
