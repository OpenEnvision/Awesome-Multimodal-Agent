import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {rowHTML,esc,PAGE_SIZE} from '../../assets/site/library.js';
import {researchMap} from './research-map.mjs';
const templates=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const root=path.resolve(templates,'..');
const out=path.join(root,'dist');
const catalog=JSON.parse(await fs.readFile(path.join(root,'assets/site/catalog.json'),'utf8'));
let html=await fs.readFile(path.join(templates,'index.template.html'),'utf8');
const values={
 COUNT:String(catalog.entries.length),
 SPAN:`${Math.min(...catalog.years)}–${Math.max(...catalog.years)}`,
 YEARS:catalog.years.map(y=>`<option value="${y}">${y}</option>`).join(''),
 SIDEBAR:`<h3 class="sidebar-heading">Collections</h3><a class="category-button active" href="?">All entries <span>${catalog.entries.length}</span></a>`+catalog.collections.map(c=>`<a class="category-button" href="?collection=${c.id}#library">${esc(c.label)}<span>${c.count}</span></a>`).join(''),
 ENTRIES:catalog.entries.slice(0,PAGE_SIZE).map(e=>rowHTML(e)).join(''),
 AGENT_LOOP:await fs.readFile(path.join(templates,'agent-loop.html'),'utf8'),
 TAXONOMY:researchMap(catalog,await fs.readFile(path.join(templates,'taxonomy.html'),'utf8'))
};
for(const [key,value]of Object.entries(values)) html=html.replaceAll(`{{${key}}}`,value);
if(/\{\{[A-Z_]+\}\}/.test(html))throw new Error('Unresolved page placeholder');
const defaultURL='https://openenvision.github.io/Awesome-Multimodal-Agent/';
const canonicalURL=process.env.SITE_URL?new URL(process.env.SITE_URL.replace(/\/$/,'')+'/').href:defaultURL;
if(process.env.SITE_URL) {
  const url=new URL(canonicalURL);
  if(url.protocol!=='https:')throw new Error('SITE_URL must use HTTPS');
  html=html.replaceAll(defaultURL,esc(canonicalURL));
}
await fs.rm(out,{recursive:true,force:true});
await fs.mkdir(out,{recursive:true});
await fs.cp(path.join(root,'assets/site'),path.join(out,'assets/site'),{recursive:true});
const pages={
 'index.html':html,
 '.nojekyll':'',
 'robots.txt':`User-agent: *\nAllow: /\nSitemap: ${canonicalURL}sitemap.xml\n`,
 'sitemap.xml':`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${esc(canonicalURL)}</loc><lastmod>${catalog.updated}</lastmod></url></urlset>\n`
};
for(const [name,content] of Object.entries(pages)) {
 await fs.writeFile(path.join(root,name),content);
 await fs.writeFile(path.join(out,name),content);
}
console.log('Website entry: '+path.join(root,'index.html'));
console.log('GitHub Actions artifact: '+out);
