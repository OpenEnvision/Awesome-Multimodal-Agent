# Awesome Multimodal Agents — OpenEnvision Library

A static companion to the research README, using the shared [OpenEnvision Library design](https://openenvision.github.io/Awesome-Multimodal-Modeling/).

## Repository layout

The deployable `index.html` is next to `README.md` at the repository root:

```text
README.md
index.html                 # generated homepage; commit this file
.nojekyll                  # bypass Jekyll for branch publishing
robots.txt
sitemap.xml
assets/
  logo-agent.png           # README logo
  site/                    # website styles, scripts, icons, and catalog
website/
  index.template.html      # editable page template
  agent-loop.html
  taxonomy.html
  scripts/                 # build, preview, and research-map helpers
scripts/                   # README extraction and deployment checks
.github/workflows/pages.yml
```

`website/` contains authoring templates and helpers. It is not the publishing root. The generated `dist/` folder is an isolated GitHub Actions artifact and is ignored by Git.

## GitHub Pages — publish from the root

1. Commit/upload the project files so `index.html`, `README.md`, `.nojekyll`, and `assets/` are at the repository's top level, not inside an extra `website/` or ZIP wrapper folder.
2. Open the repository's **Settings → Pages**.
3. Set **Source → Deploy from a branch**, **Branch → main**, and **Folder → / (root)**, then **Save**.
4. Wait for GitHub's **pages build and deployment** run to finish. The published address appears in Settings → Pages.

No Node.js build is needed on GitHub for this mode: the committed root files already contain the complete website. After editing the research README or website templates locally, run `npm run build`, then commit the refreshed `index.html`, `assets/site/catalog.json`, `robots.txt`, and `sitemap.xml` together with your edits.

## Optional — automatic README builds with GitHub Actions

For frequent README updates made directly on GitHub, select **Settings → Pages → Source → GitHub Actions** instead. The included **Deploy OpenEnvision Library** workflow regenerates the catalog, builds, checks, and deploys on pushes to `main`. After enabling this mode for the first time, run the workflow manually from **Actions → Deploy OpenEnvision Library → Run workflow**, or push a new commit.

The workflow reads the selected Pages source. When branch publishing is selected, it validates the build and leaves publication to GitHub's branch deployment. When Actions is selected, it publishes only the `dist/` artifact. It does not change repository settings or create source commits. The checked-in root homepage is refreshed by local `npm run build`; Actions regenerates its own deployment copy without committing it back.

The expected address for the OpenEnvision repository is `https://openenvision.github.io/Awesome-Multimodal-Agent/`. Uploading local files does not itself enable Pages. Relative asset paths support both a domain root and a project subdirectory.

Official instructions: [Configure a GitHub Pages publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Local development

From the repository root, run `npm run dev`, then open `http://127.0.0.1:5173/`. The existing `/Awesome-Multimodal-Agent/` preview path also works. Node.js 22 or newer is required; no npm dependencies need to be installed.

Run `npm run build` after changing the research README or templates. It writes the catalog to `assets/site/catalog.json`, generates the root homepage, and stages only website runtime files in `dist/`. Edit the README for research content and `website/index.template.html` for page layout; generated output is refreshed on every build.

Run `npm test` for catalog and browsing logic. Run `npm run check:site` after building to verify both the root site and the deployment artifact, their resource paths, and the README logo.

For another HTTPS host, set `SITE_URL` during the build to update canonical, Open Graph, robots, and sitemap URLs. The Actions workflow uses the actual Pages URL returned by GitHub. The OpenEnvision project URL is the local default.

## Design and content

- `website/index.template.html`: page shell, branding, and copy.
- `website/agent-loop.html` and `assets/site/agent.css`: an accessible, clockwise observe–decide–act–feedback explanation and agent-specific presentation.
- `assets/site/styles.css`: the companion Library's original design tokens, typography, spacing, and responsive layout; agent-specific additions are marked at the end.
- `assets/site/app.js` and `library.js`: filtering, pagination, detail dialogs, shareable views, and device-local bookmarks.
- `website/taxonomy.html` and `website/scripts/research-map.mjs`: contribution and action-domain navigation, with counts and destinations resolved from the catalog.
- `website/scripts/build.mjs`: static rendering and public assets.

The logo, shared website styles, and base interaction components come from OpenEnvision's Multimodal Modeling website, as requested. They are adapted for this companion library rather than presented as a new third-party identity. The GitHub icon's license is preserved in `assets/site/OCTICONS-LICENSE.txt`.

Content differs intentionally from the reference: an agent interaction loop replaces the input–model–output illustration. Two complementary navigation lists replace the four generic architecture diagrams and their legend. Contribution type determines a work's primary placement; action domains connect systems with their corresponding benchmarks. Six domains include information seeking, creation, conversation, software, virtual worlds, and robotics. The four additional collections remain directly accessible beneath the research map.

System rows label their feedback evidence, and their detail dialogs place it before the remaining metadata. Models, methods, and benchmarks do not receive this system-specific evidence treatment. The footer links back to the Modeling library and OpenEnvision research hub. Bookmarks use a separate storage key so they do not overwrite the Modeling library's reading list on the shared GitHub Pages origin.

## Verification — 2026-09-15

- Desktop comparison at 1280 × 720: shared 74 px header, 48 px gutters, two-column hero, statistics band, and sidebar/list layout.
- Original white background, `#171717` text, `#ce352c` accent, font stacks, and borders retained. Tablet and mobile layouts adapt the agent loop and the two navigation lists for readability.
- Mobile check at 390 × 844: no horizontal overflow; category menu, cards, and primary navigation remain usable.
- Browser checks: paper-ID search, combined year/resource filters, nested robot collection, pagination, empty state, detail dialog, persistent saved list, and shareable URL.
- Agent revision: all six paired system/benchmark destinations resolve from catalog sections; robot links show 27 systems and 35 benchmarks. The system detail view shows returned feedback once, above publication metadata. Mobile layouts have no horizontal overflow at 390 px.
- Catalog checks: 360 research entries and 87 resources, all dated README research entries included exactly once, complete system feedback-loop metadata retained. Eight automated tests pass; browser console shows no warnings or errors in the tested flows.
